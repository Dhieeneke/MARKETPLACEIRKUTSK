# Intergalactic Analytics Service — Frontend

Этот репозиторий содержит реализацию интерфейса для Сервиса межгалактической аналитики на базе React и Vite.

## 📦 Структура проекта

```
├── public               # статические файлы
├── src
│   ├── assets           # изображения, шрифты
│   ├── components       # повторно используемые UI-компоненты
│   ├── hooks            # React-хуки (если потребуется)
│   ├── pages            # страницы и роуты
│   │   ├── HomePage.tsx
│   │   ├── GeneratePage.tsx
│   │   ├── HistoryPage.tsx
│   │   └── NotFoundPage.tsx
│   ├── services         # модули для работы с API (fetch)
│   ├── store            # Zustand state-менеджер
│   ├── styles           # глобальные стили и CSS Modules
│   ├── utils            # утилиты и вспомогательные функции
│   ├── App.tsx          # корневой компонент с роутингом
│   ├── main.tsx         # точка входа приложения
│   └── vite-env.d.ts    # типизация Vite
├── .eslintrc.js         # конфигурация ESLint
├── .prettierrc          # конфигурация Prettier
├── tsconfig.json        # конфигурация TypeScript
├── vite.config.ts       # конфигурация Vite
└── package.json         # зависимости и скрипты
```

## 🚀 Быстрый старт

1. Убедитесь, что у вас установлены Node.js (>=16) и npm или Yarn.
2. Склонируйте репозиторий:
   ```bash
   git clone <URL_ВАШЕГО_РЕПОЗИТОРИЯ>
   cd <папка_проекта>
   ```
3. Установите зависимости:
   ```bash
   npm install
   # или yarn install
   ```
4. Запустите приложение в режиме разработки:
   ```bash
   npm run dev
   # или yarn dev
   ```
5. Откройте в браузере: [http://localhost:5173](http://localhost:5173)

## 🔧 Описание архитектуры

- **Сборка:** Vite + React + TypeScript
- **Стили:** CSS Modules
- **State:** Zustand для локального состояния, история загрузок хранится в LocalStorage
- **Роутинг:** react-router-dom
- **API:** Fetch API (+ точки интеграции с бэкэндом)
- **Модалы:** React Portal
- **Код-стайл:** ESLint + Prettier

### Основные модули

- **HomePage (Главная):**
  - Загрузка таблицы (drag&drop или кнопка)
  - Индикация прогресса обработки
  - Обработка ошибок
  - Сохранение записи в историю
  - Сброс интерфейса

- **GeneratePage (Генератор тестовых данных):**
  - Генерация тестовой таблицы через API
  - Автоматическая загрузка файла
  - Обработка ошибок

- **HistoryPage (История загрузок):**
  - Загрузка записей из LocalStorage
  - Удаление отдельных записей
  - Очистка истории
  - Открытие модального окна с хайлайтами по записи

## 📋 Скрипты

- `npm run dev` — запуск в режиме разработки
- `npm run build` — сборка для продакшена
- `npm run preview` — предпросмотр продакшен-сборки
- `npm run lint` — проверка кода через ESLint
- `npm run format` — автоформатирование через Prettier
