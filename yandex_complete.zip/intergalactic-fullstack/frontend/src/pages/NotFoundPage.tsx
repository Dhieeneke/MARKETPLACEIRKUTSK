import React from 'react';

const NotFoundPage: React.FC = () => (
  <div>
    <h1>404 — Страница не найдена</h1>
  </div>
);

export default NotFoundPage;
