import React, { useState } from 'react';
import { useHistoryStore, HistoryEntry } from '../store/useHistoryStore';
import HistoryList from '../components/HistoryList';
import { useNavigate } from 'react-router-dom';
import Modal from '../components/Modal';

const HistoryPage: React.FC = () => {
  const entries = useHistoryStore((state) => state.entries);
  const removeEntry = useHistoryStore((state) => state.removeEntry);
  const clear = useHistoryStore((state) => state.clear);
  const [selected, setSelected] = useState<HistoryEntry | null>(null);
  const navigate = useNavigate();

  const openModal = (entry: HistoryEntry) => setSelected(entry);
  const closeModal = () => setSelected(null);

  return (
    <div className="container">
      <h1>История загрузок</h1>
      <button onClick={() => navigate('/generate')}>Сгенерировать больше</button>
      <button onClick={() => clear()}>Полная очистка</button>
      <HistoryList entries={entries} onDelete={removeEntry} onSelect={openModal} />
      {selected && (
        <Modal onClose={closeModal}>
          <h3>Highlights для {selected.filename}</h3>
          <pre>{selected.highlights}</pre>
        </Modal>
      )}
    </div>
  );
};

export default HistoryPage;