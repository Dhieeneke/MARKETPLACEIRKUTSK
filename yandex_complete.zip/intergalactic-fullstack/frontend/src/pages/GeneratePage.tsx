import React, { useState } from 'react';
import { generateTable } from '../services/api';

const GeneratePage: React.FC = () => {
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    setError('');
    try {
      const blob = await generateTable();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'test-data.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <div className="container">
      <h1>Генератор тестовых данных</h1>
      <button onClick={handleGenerate}>Сгенерировать</button>
      {error && <div className="error">{error}</div>}
    </div>
  );
};

export default GeneratePage;