import React, { useState } from 'react';
import FileUpload from '../components/FileUpload';
import ProgressBar from '../components/ProgressBar';
import { uploadTable } from '../services/api';
import { useHistoryStore } from '../store/useHistoryStore';

const HomePage: React.FC = () => {
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [highlight, setHighlight] = useState('');
  const addEntry = useHistoryStore((state) => state.addEntry);

  const handleFile = async (file: File) => {
    setError('');
    setProgress(0);
    try {
      const data = await uploadTable(file, setProgress);
      setHighlight(data.highlights);
      addEntry({ id: data.id, filename: data.filename, date: new Date().toISOString(), highlights: data.highlights });
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleClear = () => {
    setProgress(0);
    setError('');
    setHighlight('');
  };

  return (
    <div className="container">
      <h1>Главная</h1>
      <FileUpload onFileSelect={handleFile} />
      {progress > 0 && <ProgressBar percent={progress} />}
      {highlight && (
        <div>
          <h3>Highlights</h3>
          <pre>{highlight}</pre>
        </div>
      )}
      {error && <div className="error">{error}</div>}
      <button onClick={handleClear}>Очистить</button>
    </div>
  );
};

export default HomePage;