import React from 'react';
import styles from './ProgressBar.module.css';

const ProgressBar: React.FC<{ percent: number }> = ({ percent }) => (
  <div className={styles.bar}>
    <div className={styles.fill} style={{ width: `${percent}%` }}>{percent}%</div>
  </div>
);

export default ProgressBar;