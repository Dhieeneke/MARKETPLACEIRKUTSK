import React, { useRef } from 'react';
import styles from './FileUpload.module.css';

const FileUpload: React.FC<{ onFileSelect: (file: File) => void }> = ({ onFileSelect }) => {
  const fileInput = useRef<HTMLInputElement>(null);

  const handleFiles = (files: FileList | null) => {
    if (files && files[0]) onFileSelect(files[0]);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div
      className={styles.upload}
      onDrop={onDrop}
      onDragOver={(e) => e.preventDefault()}
      onClick={() => fileInput.current?.click()}
    >
      <p>Перетащите файл или кликните для выбора</p>
      <input
        type="file"
        accept=".csv"
        ref={fileInput}
        className={styles.input}
        onChange={(e) => handleFiles(e.target.files)}
      />
    </div>
  );
};

export default FileUpload;