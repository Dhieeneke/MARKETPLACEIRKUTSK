import React from 'react';
import styles from './HistoryList.module.css';

export interface Entry { id: string; filename: string; date: string; highlights: string; }

const HistoryList: React.FC<{
  entries: Entry[];
  onDelete: (id: string) => void;
  onSelect: (entry: Entry) => void;
}> = ({ entries, onDelete, onSelect }) => (
  <ul className={styles.list}>
    {entries.map((e) => (
      <li key={e.id} className={styles.item}>
        <span onClick={() => onSelect(e)} className={styles.link}>
          {e.filename} ({new Date(e.date).toLocaleString()})
        </span>
        <button onClick={() => onDelete(e.id)}>Удалить</button>
      </li>
    ))}
  </ul>
);

export default HistoryList;