import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header: React.FC = () => {
  return (
    <header className={styles.header}>
      <nav className={styles.nav}>
        <ul className={styles.list}>
          <li>
            <NavLink to="/" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              Главная
            </NavLink>
          </li>
          <li>
            <NavLink to="/generate" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              Генератор
            </NavLink>
          </li>
          <li>
            <NavLink to="/history" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              История
            </NavLink>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
