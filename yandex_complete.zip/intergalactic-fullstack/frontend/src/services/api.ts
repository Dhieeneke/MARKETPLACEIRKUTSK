export const uploadTable = async (file: File, onProgress: (percent: number) => void): Promise<{id: string; filename: string; highlights: string}> => {
  const url = '/api/upload';
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(url, { method: 'POST', body: formData });
  if (!response.body) {
    throw new Error('ReadableStream not supported');
  }
  const reader = response.body.getReader();
  const contentLengthHeader = response.headers.get('Content-Length');
  const contentLength = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;
  let receivedLength = 0;
  const chunks: Uint8Array[] = [];
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      receivedLength += value.length;
      if (contentLength) {
        onProgress(Math.round((receivedLength / contentLength) * 100));
      }
    }
  }
  onProgress(100);
  const text = new TextDecoder().decode(chunks.reduce((acc, val) => {
    const tmp = new Uint8Array(acc.length + val.length);
    tmp.set(acc, 0);
    tmp.set(val, acc.length);
    return tmp;
  }, new Uint8Array()));
  const data = JSON.parse(text);
  return data;
};

export const generateTable = async (): Promise<Blob> => {
  const response = await fetch('/api/generate', { method: 'GET' });
  if (!response.ok) throw new Error('Ошибка генерации');
  return await response.blob();
};