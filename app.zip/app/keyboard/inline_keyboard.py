from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def feedback(): return InlineKeyboardMarkup(row_width=1).add(
    InlineKeyboardButton("Разработчик 🧑‍💻", url="https://t.me/yumi_none")
)


def barier(): return InlineKeyboardMarkup(row_width=1).add(
    InlineKeyboardButton("Богдан Бережной", url="https://t.me/solonle")
)


def admin_panel(): return InlineKeyboardMarkup(row_width=2).add(
    InlineKeyboardButton("Статистика 🚀", callback_data="stat")
)