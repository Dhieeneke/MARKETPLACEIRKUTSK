from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


def start_keyboard():
    return ReplyKeyboardMarkup(resize_keyboard=True).add(
        KeyboardButton(text="Опубликовать товар 📦")
    ).row(
        KeyboardButton(text="Сделать заказ ✍"), KeyboardButton(text="Консьерж 🧢")
    ).add(
        KeyboardButton(text="Внести свой вклад в мир MarketPlace 📨")
    )
