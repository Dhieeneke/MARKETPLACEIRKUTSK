import sqlite3
from re import sub

conn = sqlite3.connect('data/users.db')
cursor = conn.cursor()

with conn:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS MARKET_USERS (
    id INTEGER,
    username TEXT
    );
    """)


def check_new_users(id, user_name):
    if conn.execute(f"SELECT id FROM MARKET_USERS WHERE id = {id}").fetchone():
        return f"Пользователь @{user_name} перезапустил бота"
    else:
        conn.execute(rf"""
        INSERT INTO MARKET_USERS (id, username) VALUES (?, ?)
    """, (id, user_name))
        conn.commit()
        return f"Пользователь @{user_name} запустил бота"

def state_bot():
    users = conn.execute(r"""
        SELECT count(*) FROM MARKET_USERS;
    """).fetchone()
    return sub("[(,)]", "", str(users))
