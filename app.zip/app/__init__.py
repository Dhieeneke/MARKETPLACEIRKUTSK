__author__ = 'Yumi'
__telegram__ = '@yumi_none'
__version__ = '1.0'
