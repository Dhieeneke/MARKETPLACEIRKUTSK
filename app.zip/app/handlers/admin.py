from aiogram import Dispatcher
from aiogram.types import CallbackQuery
from loader import bot
from keyboard.inline_keyboard import admin_panel
from data.base import state_bot
from start_text import statistic_text


async def callback(call: CallbackQuery):
    if call.data == "stat":
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=f"{statistic_text} {state_bot()}",
            reply_markup=admin_panel()
        )


def registered_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(callback)
