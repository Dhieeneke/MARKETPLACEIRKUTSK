from aiogram.dispatcher import FSMContext
from aiogram import Dispatcher
from aiogram.types import Message, MediaGroup
from loader import bot, UserState
from keyboard.inline_keyboard import feedback, barier, admin_panel
from keyboard.reply_keyboard import start_keyboard
from typing import List
from config import chat_group, dev_id
from start_text import start_text, publication_text, zakaz_text, concierge_text, feedback_text, admin_text


async def start(message: Message, state: FSMContext):
    await state.finish()
    if message.chat.id == dev_id:
        await bot.send_message(message.chat.id, text=admin_text, reply_markup=admin_panel())
    else:
        await bot.send_message(message.chat.id, text=start_text(message.from_user.username), reply_markup=start_keyboard())


async def msg(message: Message, state: FSMContext):
    if message.text == "Опубликовать товар 📦":
        await bot.send_message(message.chat.id, text=publication_text, parse_mode="MARKDOWN")
        await UserState.photos.set()
    elif message.text == "Сделать заказ ✍":
        await state.reset_data()
        await state.finish()
        await bot.send_message(message.chat.id, text=zakaz_text, reply_markup=barier())
    elif message.text == "Консьерж 🧢":
        await state.reset_data()
        await state.finish()
        await bot.send_message(message.chat.id, text=concierge_text)
    if message.text == "Внести свой вклад в мир MarketPlace 📨":
        await state.reset_data()
        await state.finish()
        await bot.send_message(message.chat.id, text=feedback_text,
                               reply_markup=feedback())


async def process_media_group(message: Message, state: FSMContext, album: List[Message]):
    media_group = MediaGroup()
    await state.update_data(caption=message.caption)
    data = await state.get_data()
    if message.media_group_id:
        for obj in album:
            if obj.photo:
                file_id = obj.photo[-1].file_id
            try:
                media_group.attach_photo(file_id)
            except ValueError:
                pass
        media_group.media[0]['caption'] = data['caption'] + f"\nДля связи обращайтесь к @{message.from_user.username}"
        await bot.send_media_group(chat_group, media=media_group)
        await bot.send_message(message.chat.id, "Ваш товар был отправлен на модерацию")
    await state.finish()


def registered_handlers(dp: Dispatcher):
    dp.register_message_handler(start, commands={'start', 'restart'}, state="*")
    dp.register_message_handler(msg, state="*", content_types="text")
    dp.register_message_handler(process_media_group, content_types="any", state=UserState.photos)
