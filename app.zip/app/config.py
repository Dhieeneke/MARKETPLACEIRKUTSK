

from dotenv import load_dotenv, dotenv_values

load_dotenv()

key = dotenv_values().get("TOKEN")
chat_group = int(dotenv_values().get["CHAT_GROUP_ID"])
dev_id = int(dotenv_values().get["DEV_ID"])
