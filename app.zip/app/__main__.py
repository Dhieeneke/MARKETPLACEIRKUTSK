from aiogram import executor
from loader import dp
from handlers import client, admin
from middlewares.AlbumMiddleware import AlbumMiddleware

client.registered_handlers(dp)
admin.registered_handlers(dp)
dp.middleware.setup(AlbumMiddleware())

if __name__ == "__main__": executor.start_polling(dp, skip_updates=True)
